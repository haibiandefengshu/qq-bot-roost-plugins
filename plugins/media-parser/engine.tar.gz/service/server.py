"""本地 HTTP 服务：给 MCP 服务与桥接钩子提供解析入口。

只监听回环地址；配置了 token 时要求 `Authorization: Bearer <token>`。
请求/响应都是 JSON，媒体以**本地绝对路径**返回，由 QQ 侧直接读取发送。
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, Dict

from . import paths

paths.install()

from aiohttp import web  # noqa: E402

from core.logger import logger  # noqa: E402

from .config import (  # noqa: E402
    QQSettings,
    build_engine_config,
    ensure_ffmpeg,
    load_raw_config,
    parse_qq_settings,
)
from .engine import MediaEngine, ParseError  # noqa: E402

VERSION = "1.0.0"


def _redact(value: Any) -> Any:
    """递归脱敏：不把 cookie / api key 回显给调用方。"""
    if isinstance(value, dict):
        result: Dict[str, Any] = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if any(word in lowered for word in ("cookie", "api_key", "apikey", "token", "secret")):
                result[key] = "***" if item else ""
            else:
                result[key] = _redact(item)
        return result
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value


def create_app(engine: MediaEngine, settings: QQSettings, raw_config: Dict[str, Any]) -> web.Application:
    """构造 aiohttp 应用。"""
    app = web.Application(client_max_size=4 * 1024 * 1024)
    started_at = time.time()

    def unauthorized(request: web.Request) -> bool:
        if not settings.token:
            return False
        header = request.headers.get("Authorization", "")
        token = header[7:].strip() if header.lower().startswith("bearer ") else ""
        token = token or request.headers.get("X-Engine-Token", "").strip()
        return token != settings.token

    async def guard(request: web.Request) -> None:
        if unauthorized(request):
            raise web.HTTPUnauthorized(text=json.dumps({"ok": False, "error": "token 不正确"}), content_type="application/json")

    async def read_json(request: web.Request) -> Dict[str, Any]:
        if not request.can_read_body:
            return {}
        try:
            payload = await request.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise web.HTTPBadRequest(
                text=json.dumps({"ok": False, "error": f"请求体不是合法 JSON: {exc}"}),
                content_type="application/json",
            )
        if not isinstance(payload, dict):
            raise web.HTTPBadRequest(
                text=json.dumps({"ok": False, "error": "请求体必须是 JSON 对象"}),
                content_type="application/json",
            )
        return payload

    @web.middleware
    async def error_middleware(request: web.Request, handler):
        try:
            return await handler(request)
        except web.HTTPException:
            raise
        except ParseError as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - 顶层兜底
            logger.exception(f"处理请求失败: {request.path}: {exc}")
            return web.json_response({"ok": False, "error": str(exc)}, status=500)

    app.middlewares.append(error_middleware)

    
    async def health(request: web.Request):
        await guard(request)
        return web.json_response(
            {
                "ok": True,
                "version": VERSION,
                "uptimeSeconds": int(time.time() - started_at),
                "platforms": len(engine.platform_list()),
                "cacheDir": settings.cache_dir,
                "cacheAvailable": bool(engine.cfg.download.cache_dir_available),
                "translation": bool(engine.cfg.translation.enabled),
                "renderTextToImage": bool(
                    engine.cfg.message.text_metadata.render_to_image
                ),
                "ffmpeg": bool(settings.ffmpeg_path),
            }
        )

    
    async def platforms(request: web.Request):
        await guard(request)
        return web.json_response({"ok": True, "platforms": engine.platform_list()})

    
    async def config_view(request: web.Request):
        await guard(request)
        return web.json_response(
            {
                "ok": True,
                "qq": _redact(raw_config.get("qq") or {}),
                "upstream": _redact(
                    {key: value for key, value in raw_config.items() if key != "qq"}
                ),
            }
        )

    
    async def parse(request: web.Request):
        await guard(request)
        payload = await read_json(request)
        text = str(payload.get("text") or "").strip()
        if not text:
            raise ParseError("缺少 text")
        outcome = await engine.parse(
            text,
            user_key=str(payload.get("userKey") or "").strip(),
            sender_name=str(payload.get("senderName") or "解析结果"),
            sender_id=payload.get("senderId") or "0",
            quote_id=str(payload.get("quoteId") or "").strip(),
            quote_first_text=bool(payload.get("quoteFirstText") or False),
        )
        return web.json_response(outcome.to_dict())

    
    async def archive(request: web.Request):
        await guard(request)
        payload = await read_json(request)
        text = str(payload.get("text") or "").strip()
        if not text:
            raise ParseError("缺少 text")
        path, summary = await engine.build_archive(
            text, user_key=str(payload.get("userKey") or "").strip()
        )
        return web.json_response(
            {"ok": True, "file": os.path.abspath(path), "summary": summary}
        )

    
    async def clean(request: web.Request):
        await guard(request)
        stats = await engine.clean_cache()
        return web.json_response({"ok": True, "stats": stats})

    
    async def cleanup_files(request: web.Request):
        await guard(request)
        payload = await read_json(request)
        files = [str(item) for item in (payload.get("files") or []) if str(item).strip()]
        await engine.clean_files(files)
        return web.json_response({"ok": True, "removed": len(files)})

    
    async def index(request: web.Request):
        return web.json_response({"ok": True, "service": "media-parser-engine", "version": VERSION})

    router = app.router
    router.add_get("/", index)
    router.add_get("/health", health)
    router.add_get("/platforms", platforms)
    router.add_get("/config", config_view)
    router.add_post("/parse", parse)
    router.add_post("/archive", archive)
    router.add_post("/clean", clean)
    router.add_post("/cleanup-files", cleanup_files)

    return app


async def run(config_path: str, base_dir: str) -> None:
    """按配置文件启动服务。"""
    raw = load_raw_config(config_path)
    settings = parse_qq_settings(raw.get("qq") or {}, base_dir)
    ffmpeg = ensure_ffmpeg(settings, base_dir)
    cfg = build_engine_config(raw, settings)
    engine = MediaEngine(cfg, settings)
    await engine.start()
    app = create_app(engine, settings, raw)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, settings.host, settings.port)
    await site.start()
    logger.info(
        f"解析引擎已启动: http://{settings.host}:{settings.port} "
        f"（平台 {len(engine.platform_list())} 个，缓存 {settings.cache_dir}）"
    )
    if ffmpeg:
        logger.info(f"ffmpeg: {ffmpeg}")
    else:
        logger.warning("未找到 ffmpeg：DASH 音视频合并、转码与图片格式转换会失败")
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await runner.cleanup()
        await engine.close()
